package com.e_prescription;

public class MEDICINES {
    String caps;

    public MEDICINES() {
    }

    public MEDICINES(String caps) {
        this.caps = caps;

    }

    public String getCaps() {
        return caps;
    }

    public void setCaps(String caps) {
        this.caps = caps;
    }


}
