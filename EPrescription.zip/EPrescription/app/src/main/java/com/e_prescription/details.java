package com.e_prescription;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.speech.RecognizerIntent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Objects;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.sql.DataSource;

public class details extends AppCompatActivity {
TextView p,pt,dc,mm;
ImageButton send,scanqr,pdf;
Button btn;
urlist filelist;
    private IntentIntegrator qrScan;
    DatabaseReference ref;
    String pname,ppid,pa,padd,pphn,pmail,n4,dname,nn;
    String mfilepath,mailid;
    String downloadUrl;
    ArrayList<String> medlist;
    private StorageReference mStorageRef;
    UploadTask uploadTask;
    private static final int STORAGE_CODE =1000;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);
        mStorageRef = FirebaseStorage.getInstance().getReference();
        p=findViewById(R.id.phar);
        pt=findViewById(R.id.patient);
        mm=findViewById(R.id.med);
        dc=findViewById(R.id.doctor);
        qrScan = new IntentIntegrator(this);
        send=findViewById(R.id.mail);
        pdf=findViewById(R.id.save);
        btn=findViewById(R.id.button);
        scanqr=findViewById(R.id.scan);
        medlist=new ArrayList<>();
        p.setText(getIntent().getStringExtra("Pharmacy"));
        mailid=(getIntent().getStringExtra("mail"));
        dname=(getIntent().getStringExtra("name"));
        scanqr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                qrScan.initiateScan();
            }
        });
         btn.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent i=new Intent(getApplicationContext(),MainActivity.class);
            startActivity(i);
         }
         });
        DatabaseReference ref1=FirebaseDatabase.getInstance().getReference().child("PRESCRIPTION").child(Objects.requireNonNull(FirebaseAuth.getInstance().getUid())).child("PRES");
        ref1.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for(DataSnapshot ds:dataSnapshot.getChildren())
                {
                    String n= ds.getKey();
                    assert n != null;
                    String dos= Objects.requireNonNull(ds.child("Dosage").getValue()).toString();
                    String nod= Objects.requireNonNull(ds.child("no_of_days").getValue()).toString();
                    String f=""+n+":\nDays:"+nod+"\nTimings:"+dos+".\n";
                    String a=mm.getText().toString();
                    a=a+"\n"+f;
                    mm.setText(a);
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });
        FirebaseDatabase firebaseDatabase=FirebaseDatabase.getInstance();
        final DatabaseReference register = firebaseDatabase.getReference().child("Doctors").child(FirebaseAuth.getInstance().getUid());
        register.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String n= Objects.requireNonNull(dataSnapshot.child("add").getValue()).toString();
                String n1= Objects.requireNonNull(dataSnapshot.child("deg").getValue()).toString();
                String n2= Objects.requireNonNull(dataSnapshot.child("email").getValue()).toString();
                String n3= Objects.requireNonNull(dataSnapshot.child("name").getValue()).toString();
                String n5= Objects.requireNonNull(dataSnapshot.child("phn").getValue()).toString();
                n4="Prescribed By,\nDr."+n3+" "+n1+"\n"+n+",\n"+n5+",\n"+n2+".";
                dc.setText(n4);
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        pdf.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(Build.VERSION.SDK_INT>Build.VERSION_CODES.M){
                    if(checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)== PackageManager.PERMISSION_DENIED){
                        String[] permissions={Manifest.permission.WRITE_EXTERNAL_STORAGE};
                        requestPermissions(permissions, STORAGE_CODE);
                    }
                    else{
                        savepdf();
                    }
                }else{
                    savepdf();
                }
            }
        });
        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendMail();
            }
        });
    }
    private void savepdf() {
        final Document mDoc=new Document();
        String mfilename=new SimpleDateFormat("MMdd_HHmm", Locale.getDefault()).format(System.currentTimeMillis());
        final String p=pname+ppid+mfilename;
         mfilepath= Environment.getExternalStorageDirectory()+"/"+p+".pdf";
        try {
            PdfWriter.getInstance(mDoc,new FileOutputStream(mfilepath));
            mDoc.open();
             mDoc.addAuthor(n4);
            mDoc.add(new Paragraph("\nPrescription\n"));
            String patient=pt.getText().toString();
            mDoc.add(new Paragraph("\nPatient Details:\n"));
             mDoc.add(new Paragraph(patient));
             String medc=mm.getText().toString();
            mDoc.add(new Paragraph("\n\n"));
            mDoc.add(new Paragraph(medc));
            mDoc.add(new Paragraph("\n\n"));
            mDoc.add(new Paragraph(n4));
             mDoc.close();
            final Uri file = Uri.fromFile(new File(mfilepath));
            final StorageReference riversRef = mStorageRef.child("Prescription").child(dname).child(p);
            riversRef.putFile(file).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onSuccess(final UploadTask.TaskSnapshot taskSnapshot) {
                    riversRef.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                        @Override
                        public void onSuccess(Uri uri) {
                            String url=String.valueOf(uri);
                            filelist=new urlist(p,url);
                            ref=FirebaseDatabase.getInstance().getReference().child("Doctors").child(FirebaseAuth.getInstance().getUid()).child("Preslist");
                            ref.child(pname+ppid).push().setValue(filelist);
                            downloadUrl=url;
                        }
                    });
                    Toast.makeText(getBaseContext(), "pdf stored", Toast.LENGTH_SHORT).show();
                }
            });
            final StorageReference riversRef1 = mStorageRef.child("Prescription").child(nn);
            riversRef1.putFile(file).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onSuccess(final UploadTask.TaskSnapshot taskSnapshot) {
                    riversRef1.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                        @Override
                        public void onSuccess(Uri uri) {
                            String url=String.valueOf(uri);
                            filelist=new urlist(p,url);
                            ref=FirebaseDatabase.getInstance().getReference().child("Patients").child(nn).child("Preslist");
                            ref.push().setValue(filelist);
                        }
                    });
                    Toast.makeText(getBaseContext(), "pdf stored", Toast.LENGTH_SHORT).show();
                }
            });
        }catch (Exception e){
            Toast.makeText(this,e.getMessage(),Toast.LENGTH_LONG).show();
        }
       // sendMail();
        Toast.makeText(this,"you can now send email ",Toast.LENGTH_LONG).show();

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode){
            case STORAGE_CODE:
                if(grantResults.length>0&&grantResults[0]==PackageManager.PERMISSION_GRANTED){
                        savepdf();
                }
                else {
                    Toast.makeText(this,"Permission Denied...!",Toast.LENGTH_LONG).show();
                }
        }
    }

    private void sendMail()
    {
        String mail=mailid;
        String msg=downloadUrl;
        String sub=pt.getText().toString().trim();
        JavaMailAPI javaMailAPI=new JavaMailAPI(this,mail,sub,msg);
        javaMailAPI.execute();
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        if (result != null) {
            //if qrcode has nothing in it
            if (result.getContents() == null) {
                Toast.makeText(this, "Result Not Found", Toast.LENGTH_LONG).show();
            } else {

                try {
                    //converting the data to json
                    JSONObject obj = new JSONObject(result.getContents());
                    //setting values to textviews
                    pname=obj.getString("name");
                     ppid=obj.getString("pid");
                     pa=obj.getString("dob");
                     padd=obj.getString("add");
                     pphn=obj.getString("phn");
                     pmail=obj.getString("mail");
                        padd=padd.trim();
                     nn=pname+ppid;
                    String name="Patient Name:"+pname+"\nPatient-id:"+ppid+"\nAge:"+pa+"\nAddress:"+padd+"\nPhone:"+pphn+"\nMail-id:"+pmail+".";
                    pt.setText(name);
                    //nn=pt.getText().toString();
                    DatabaseReference ref=FirebaseDatabase.getInstance().getReference().child("Patients").child(nn);
                    ref.child("name").setValue(pname);
                    ref.child("pid").setValue(ppid);
                } catch (JSONException e) {
                    e.printStackTrace();
                    Toast.makeText(this, result.getContents(), Toast.LENGTH_LONG).show();
                }
            }
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }
}
