package com.e_prescription;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class forg extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forg);
    }
}
