package com.e_prescription;

public class Utils {

    public static final String EMAIL="mini2020project@gmail.com";
    public static final String PASSWORD="mini@2020";
}
